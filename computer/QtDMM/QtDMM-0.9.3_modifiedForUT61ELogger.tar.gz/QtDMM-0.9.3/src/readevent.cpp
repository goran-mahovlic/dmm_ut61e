//======================================================================
// File:		readevent.cpp
// Author:	Matthias Toussaint
// Created:	Sun Oct  6 17:11:40 CEST 2002
//----------------------------------------------------------------------
// This file is part of QtDMM.
//
// QtDMM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 3
// as published by the Free Software Foundation.
//
// QtDMM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------
// Copyright (c) 2002 Matthias Toussaint
//======================================================================

#include <readevent.h>

#include <iostream>
//Added by qt3to4:
#include <QCustomEvent>
#include <QEvent>
/*
ReadEvent::ReadEvent( char *str, int len, int id, DataFormat df ) :
  QCustomEvent( QEvent::User ),
  m_length( len ),
  m_format (df ),
  m_id( id )
{
  memcpy( m_str, str, len );
}

ReadEvent::~ReadEvent()
{
}
*/